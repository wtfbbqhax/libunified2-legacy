#ifdef HAVE_CONFIG_H
#include "config.h"
#endif


int main( ) {
    return 0;
}
