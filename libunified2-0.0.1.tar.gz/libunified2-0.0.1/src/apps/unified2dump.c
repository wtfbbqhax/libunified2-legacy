/*******************************************************************************
 * Author:  Victor Roemer
 * Contact: vroemer@sourcefire.com
 * Date:    September 4, 2010
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#ifdef __APPLE__
#include <getopt.h>
extern char *optarg;
extern int optind;
extern int optopt;
extern int opterr;
extern int optreset;
#endif

#include "unified2.h"

static struct option longopts[] = {
    {"read", required_argument, NULL, 'r' },
    {"count", required_argument, NULL, 'n' },

    {NULL, 0, NULL, 0}
};

struct progam_vars {
    int record_count;
    char *filename;
} pv;


/* Function: parse_args
 *
 * Purpose: abstract arguement parsing outside of main
 *
 * Arguements:
 *      int
 *      char **
 *
 * Returns:
 *      int
 */
int parse_args( int argc, char *argv[] ) {
    int argi;
    int ch;

    pv.record_count = -1;
    pv.filename = NULL;

    /* Get the options */
    while((ch = getopt_long(argc, argv, "r:n:", longopts, NULL)) != -1 ) {
        argi++;
        switch(ch) {
            case 'n':
            pv.record_count = atoi(optarg);
            break;

            case 'r':
            pv.filename = strdup(optarg);
            break;

            case '?':
            default:
            warn("Usage: %s -n count -r unified2.log\n\n", argv[0]);
            return -1;
        }
    }

    if( argi >= argc && !pv.filename ) {
        pv.filename = strdup(argv[argc-1]);
    }
}

/* Function: unified2_loop
 *
 * Purpose: Open the unified2 and print its contents to stdout
 *
 * Arguements:
 *      char *
 *      int
 *
 * Returns:
 *      int
 */
int unified2_loop(char *filename, int loop_count)
{
    int r;

    Unified2Entry *entry;
    Unified2 *unified2;
 
    unified2 = Unified2New();
    entry = Unified2EntryNew();
    Unified2ReadOpenFd(unified2, filename);

    while( loop_count )
    {
        if( loop_count > 0 )
        {
            loop_count--;
        }

        r = Unified2ReadNextEntry(unified2, entry);

        if( r == UNIFIED2_EOF )
        {
            warn("EOF\n");
            break;
        }

        if( r == UNIFIED2_WARN )
        {
            warn("WARNING\n");
            break;
        }

        PrintRecord( entry );

        Unified2EntrySparseCleanup(entry);
    }

    Unified2Free(unified2);
    printf("\n");

    return(1);
}

/* Function: main
 *
 * Purpose: Its main yo!
 *
 * Arguements:
 *      int
 *      char **
 *
 * Returns:
 *      int
 */
int main( int argc, char *argv[] ) {
   int ch, r;

    parse_args( argc, argv );

    /* Check required */
    if( !pv.filename )
    {
        warn("Usage: %s -n count -r unified2.log\n\n", argv[0]);
        exit(1);
    }

    /* Loop */
    unified2_loop(pv.filename, pv.record_count);

    /* Finish */
    DONE:
    if( pv.filename )
    {
        free(pv.filename);
    }
    return 0;
}
